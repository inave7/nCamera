package com.belaku.ncam

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.Camera
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.view.animation.ScaleAnimation
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.belaku.ncam.databinding.ActivityMainBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream


class MainActivity : AppCompatActivity() {



    private lateinit var fabOpen: Animation
    private lateinit var fabClose: Animation
    private lateinit var rotateForward: Animation
    private lateinit var rotateBackward: Animation

    var isOpen = false

    private lateinit var fabMain: FloatingActionButton
    private lateinit var fab1: FloatingActionButton
    private lateinit var fab2: FloatingActionButton
    private lateinit var fab3: FloatingActionButton
    private var faceDetecting: Boolean = true
    private lateinit var fabSwap: FloatingActionButton
    private lateinit var fabCapture: FloatingActionButton
    private var switchingCamera: Boolean = false
    lateinit var mTextFieldTimer: TextView
    private var isFront: Boolean = true
    lateinit var imageViewSample: ImageView
    private lateinit var cameraPreview: FrameLayout
    private val LogTag: String = "DebugLog"
    val mPictureFrontCamera = Camera.PictureCallback { data, _ ->


        var bmp = BitmapFactory.decodeByteArray(data, 0, data.size)

        val matrix = Matrix()
        matrix.postRotate(270f)
        bmp = Bitmap.createBitmap(
            bmp,
            0,
            0,
            bmp.getWidth(),
            bmp.getHeight(),
            matrix,
            true
        )

        saveMediaToStorage(bmp)

        imageViewSample.setImageBitmap(Bitmap.createScaledBitmap(bmp, imageViewSample.width, imageViewSample.height, false))
        imageViewSample.bringToFront()
        imageViewSample.visibility = View.VISIBLE


    }

    val mPictureBackCamera = Camera.PictureCallback { data, _ ->


        var bmp = BitmapFactory.decodeByteArray(data, 0, data.size)

        val matrix = Matrix()
        matrix.postRotate(90f)
        bmp = Bitmap.createBitmap(
            bmp,
            0,
            0,
            bmp.getWidth(),
            bmp.getHeight(),
            matrix,
            true
        )

        saveMediaToStorage(bmp)

        imageViewSample.setImageBitmap(Bitmap.createScaledBitmap(bmp, imageViewSample.width, imageViewSample.height, false))
        imageViewSample.bringToFront()
        imageViewSample.visibility = View.VISIBLE
    }



    var mCamera: Camera? = null
    private var mPreview: CameraPreview? = null

    private val CAMERA_PERMISSION_CODE: Int = 1
    private lateinit var binding: ActivityMainBinding



    fun saveMediaToStorage(bitmap: Bitmap) {
        val filename = "${System.currentTimeMillis()}.jpg"
        var fos: OutputStream? = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            contentResolver?.also { resolver ->
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES)
                }
                val imageUri: Uri? =
                    resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                fos = imageUri?.let { resolver.openOutputStream(it) }
            }
        } else {
            val imagesDir =
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val image = File(imagesDir, filename)
            fos = FileOutputStream(image)
        }
        fos?.use {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, it)
            makeSnack("Saved to Photos")
        }
    }
    var handler: Handler = Handler()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)


        fabOpen = AnimationUtils.loadAnimation(this, R.anim.fab_open)
        fabClose = AnimationUtils.loadAnimation(this, R.anim.fab_close)
        rotateForward = AnimationUtils.loadAnimation(this, R.anim.rotate_forwawrd)
        rotateBackward = AnimationUtils.loadAnimation(this, R.anim.rotate_backward)


        fabMain = binding.fabMain
        fab1 = binding.fab1
        fab1.setImageBitmap(textAsBitmap("F1", 35f, Color.WHITE));
        fab2 = binding.fab2
        fab2.setImageBitmap(textAsBitmap("F2", 35f, Color.WHITE));
        fab3 = binding.fab3
        fab3.setImageBitmap(textAsBitmap("F3", 35f, Color.WHITE));

        fabCapture = binding.fabCapture
        fabSwap = binding.fabSwap
        imageViewSample = binding.imageview
        mTextFieldTimer = binding.txTimer

        // Hide the status bar.
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN
// Remember that you should never show the action bar if the
// status bar is hidden, so hide that too if necessary.
        actionBar?.hide()

        fabMain.setOnClickListener(View.OnClickListener {
            animateFab()
        })

        fab1.setOnClickListener(View.OnClickListener {
            makeSnack("Yet2ImplFilter1")
        })

        fab2.setOnClickListener(View.OnClickListener {
            makeSnack("Yet2ImplFilter2")
        })

        fab3.setOnClickListener(View.OnClickListener {
            makeSnack("Yet2ImplFilter3")
        })


        fabCapture.setOnClickListener { view ->

            if (isFront)
            mCamera?.takePicture(null, null, mPictureFrontCamera)
            else mCamera?.takePicture(null, null, mPictureBackCamera)


            handler.postDelayed(Runnable {
                mCamera?.startPreview()

                val fade_in = ScaleAnimation(
                    1f,
                    0.25f,
                    1f,
                    0.25f,
                    Animation.RELATIVE_TO_SELF,
                    0f,
                    Animation.RELATIVE_TO_SELF,
                    0f
                )
                fade_in.duration = 1000
                fade_in.fillAfter = true
                imageViewSample.startAnimation(fade_in)


            }, 2000)

        }

        fabSwap.setOnClickListener {
        //    switchCamera()
        }
    }

    private fun animateFab() {
        if (isOpen) {
            fabMain.startAnimation(rotateForward)
            fab1.startAnimation(fabClose)
            fab2.startAnimation(fabClose)
            fab3.startAnimation(fabClose)
            fab1.isClickable = false
            fab2.isClickable = false
            fab3.isClickable = false
            isOpen = false
        } else {
            fabMain.startAnimation(rotateBackward)
            fab1.startAnimation(fabOpen)
            fab2.startAnimation(fabOpen)
            fab3.startAnimation(fabOpen)
            fab1.isClickable = true
            fab2.isClickable = true
            fab3.isClickable = true
            isOpen = true
        }
    }

    fun addDotEverySecond() {
        Handler(Looper.getMainLooper()).postDelayed({
            mTextFieldTimer.text =  mTextFieldTimer.text.toString() + "."
            //condition to check needs to terminate or not.
            if(mTextFieldTimer.text.length == 25){
               return@postDelayed // just return from here to terminate this.
            }else{
                addDotEverySecond()
            }
        }, 1000)
    }


    override fun onResume() {
        super.onResume()

        //    makeSnack("checking Camera Hardware...");
        checkCameraHardware(applicationContext)
    }

    override fun onPause() {
        releaseCamera()
        super.onPause()
    }

    override fun onDestroy() {
        releaseCamera()
        super.onDestroy()
    }

    private fun releaseCamera() {

        mCamera?.release() // release the camera for other applications
        mCamera = null
    }


    public fun makeSnack(s: String) {
        Log.d(LogTag, s)
        Snackbar.make(window.decorView.rootView, s, Snackbar.LENGTH_LONG).show()
    }

    /** Check if this device has a camera */
    private fun checkCameraHardware(context: Context): Boolean {
        if (context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
     //       makeSnack("this device has a camera")
            checkPermission(Manifest.permission.CAMERA,
                CAMERA_PERMISSION_CODE)


            mCamera = getCameraInstance(1)

            mCamera?.setFaceDetectionListener(FaceDetectionListener())


            mPreview = mCamera?.let {
                // Create our Preview view
                CameraPreview(this, it)
            }

            // Set the Preview view as the content of our activity.
            mPreview?.also {
                cameraPreview = binding.cameraPreview
                cameraPreview.addView(it)
            }

            return true
        } else {
            makeSnack("no camera on this device")
            return false
        }
    }

    fun checkPermission(permission: String, requestCode: Int) {
        // Checking if permission is not granted
        if (ContextCompat.checkSelfPermission(
                this@MainActivity,
                permission
            ) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this@MainActivity, arrayOf(permission), requestCode)
        }
    }

    fun getCameraInstance(i: Int): Camera? {

        handler.postDelayed(Runnable {  },3000)
        return try {
            if (i == 1)
            Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT)
        else Camera.open(Camera.CameraInfo.CAMERA_FACING_BACK) // attempt to get a Camera instance
        } catch (e: Exception) {
            makeSnack("Excp - " + e.toString())
            // Camera is not available (in use or does not exist)
            null // returns null if camera is unavailable
        }

    }


    inner class FaceDetectionListener : Camera.FaceDetectionListener {

        override fun onFaceDetection(faces: Array<Camera.Face>, camera: Camera) {
            if (faces.isNotEmpty()) {

                if (faces.size > 0) {
                    if (isFront)
                        mCamera?.takePicture(null, null, mPictureFrontCamera)
                    else mCamera?.takePicture(null, null, mPictureBackCamera)
                    handler.postDelayed(Runnable {
                        mCamera?.startPreview()

                        object : CountDownTimer(5000, 1000) {

                            override fun onTick(millisUntilFinished: Long) {
                                mTextFieldTimer.bringToFront()
                                mTextFieldTimer.setTextColor(resources.getColor(android.R.color.holo_red_light))
                                mTextFieldTimer.setText("" + millisUntilFinished / 1000)

                                if ((millisUntilFinished / 1000).toInt() == 0) {
                                    mTextFieldTimer.setTextColor(resources.getColor(android.R.color.holo_green_light))
                                    mTextFieldTimer.setText("detecting faces...")
                                    addDotEverySecond()
                                }
                            }

                            override fun onFinish() {
                                mCamera?. stopFaceDetection()
                                mCamera?.startFaceDetection()
                            }
                        }.start()

                        val fade_in = ScaleAnimation(
                            1f,
                            0.25f,
                            1f,
                            0.25f,
                            Animation.RELATIVE_TO_SELF,
                            0f,
                            Animation.RELATIVE_TO_SELF,
                            0f
                        )
                        fade_in.duration = 1000
                        fade_in.fillAfter = true
                        imageViewSample.startAnimation(fade_in)

                        imageViewSample.setOnClickListener(View.OnClickListener {
                            val intent = Intent()
                            intent.action = Intent.ACTION_VIEW
                            intent.type = "image/*"
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(intent)
                        })


                    }, 3000)

                }

            }
        }
    }


    //method to convert your text to image
    fun textAsBitmap(text: String, textSize: Float, textColor: Int): Bitmap? {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.setTextSize(textSize)
        paint.setColor(textColor)
        paint.setTextAlign(Paint.Align.LEFT)
        val baseline: Float = -paint.ascent() // ascent() is negative
        val width = (paint.measureText(text) + 0.0f)  // round
        val height = (baseline + paint.descent() + 0.0f)
        val image = Bitmap.createBitmap(width.toInt(), height.toInt(), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(image)
        canvas.drawText(text, 0f, baseline, paint)
        return image
    }

    inner class CameraPreview(
        context: Context,
        private val mCamera: Camera
    ) : SurfaceView(context), SurfaceHolder.Callback {

        private val mHolder: SurfaceHolder = holder.apply {
            // Install a SurfaceHolder.Callback so we get notified when the
            // underlying surface is created and destroyed.
            addCallback(this@CameraPreview)
            // deprecated setting, but required on Android versions prior to 3.0
            setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS)
        }

        override fun surfaceCreated(holder: SurfaceHolder) {
            // The Surface has been created, now tell the camera where to draw the preview.
            mCamera.apply {
                try {
                    setPreviewDisplay(holder)
                    startPreview()

                    object : CountDownTimer(5000, 1000) {
                        override fun onTick(millisUntilFinished: Long) {
                            mTextFieldTimer.bringToFront()
                            mTextFieldTimer.setTextColor(resources.getColor(android.R.color.holo_red_light))
                            mTextFieldTimer.setText("" + millisUntilFinished / 1000)

                            if ((millisUntilFinished / 1000).toInt() == 0) {

                                mTextFieldTimer.setTextColor(resources.getColor(android.R.color.holo_green_light))
                                mTextFieldTimer.setText("detecting faces...")
                                addDotEverySecond()
                            }

                            // logic to set the EditText could go here
                        }

                        override fun onFinish() {
                            mCamera.startFaceDetection()
                        }
                    }.start()

                } catch (e: IOException) {
                    Log.d("TAG", "Error setting camera preview: ${e.message}")
                }
            }
        }

        override fun surfaceDestroyed(holder: SurfaceHolder) {
            // empty. Take care of releasing the Camera preview in your activity.
        }

        override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
            // If your preview can change or rotate, take care of those events here.
            // Make sure to stop the preview before resizing or reformatting it.
            if (mHolder.surface == null) {
                // preview surface does not exist
                return
            }

            // stop preview before making changes
            try {
                mCamera.stopPreview()
            } catch (e: Exception) {
                // ignore: tried to stop a non-existent preview
            }

            // set preview size and make any resize, rotate or
            // reformatting changes here

            // start preview with new settings
            mCamera.apply {
                try {
                    setPreviewDisplay(mHolder)
                    startPreview()
            //        mCamera.startFaceDetection()
                } catch (e: Exception) {
                    Log.d("TAG", "Error starting camera preview: ${e.message}")
                }
            }

            mCamera.setDisplayOrientation(90)

        }
    }
}